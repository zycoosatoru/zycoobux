import type { Config } from 'tailwindcss';
export default {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: { extend: { colors: { ink: '#09090D', silver: '#C0C0C0', platinum: '#E5E4E2', neon: '#9B5CFF', electric: '#368BFF' } } },
  plugins: [],
} satisfies Config;
