'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { PACKAGES, POPULAR, isValidRobux, MIN_ROBUX, MAX_ROBUX, PAYMENTS, PRICE_PER_ROBUX, TERMS, rupiah } from '@/lib/config';

type V = { status: 'VERIFIED'; avatar: string | null; name: string; displayName: string } | { status: 'FAILED' | 'NOT_FOUND' } | null;

export default function Home() {
  const router = useRouter();
  const [username, setUsername] = useState(''); const [displayName, setDisplayName] = useState('');
  const [v, setV] = useState<V>(null); const [verifying, setVerifying] = useState(false);
  const [robux, setRobux] = useState<number | null>(null);
  const [custom, setCustom] = useState('');
  const [method, setMethod] = useState('');
  const [checks, setChecks] = useState<boolean[]>(TERMS.map(() => false));
  const [paying, setPaying] = useState(false); const [err, setErr] = useState('');

  const verified = v?.status === 'VERIFIED';
  const total = robux ? robux * PRICE_PER_ROBUX : 0;
  const ready = verified && !!robux && !!method && checks.every(Boolean) && !paying;
  const resetV = () => setV(null);

  async function verify() {
    setVerifying(true); setErr('');
    try {
      const r = await fetch('/api/roblox-verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username, displayName }) });
      const d = await r.json(); setV(d.status ? d : { status: 'FAILED' });
    } catch { setV({ status: 'FAILED' }); }
    setVerifying(false);
  }
  async function pay() {
    setPaying(true); setErr('');
    try {
      const r = await fetch('/api/checkout', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, displayName, robux, paymentMethod: method, agreed: checks.every(Boolean) }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || 'Gagal checkout');
      router.push(`/invoice/${d.orderId}`);
    } catch (e: any) { setErr(e.message); setPaying(false); }
  }
  const pm = PAYMENTS[method];

  return (
    <main className="mx-auto max-w-6xl px-4">
      <section className="pt-16 text-center">
        <h1 className="metal-text text-4xl font-black tracking-tight md:text-6xl">TOPUP ROBUX VIA USERNAME</h1>
        <p className="mx-auto mt-4 max-w-xl text-silver">Top Up Robux dengan mudah, cepat, dan nyaman bersama ZYCOOBUX.</p>
        <div className="relative mx-auto mt-10 w-fit">
          <div className="absolute -inset-10 -z-10 rounded-full bg-neon/25 blur-3xl" />
          <div className="rounded-3xl bg-gradient-to-br from-platinum via-silver/40 to-neon/60 p-[3px]">
            <div className="rounded-3xl bg-ink p-3"><img src="/images/logo-zycoo.png" alt="ZYCOOBUX" className="h-56 w-56 rounded-2xl object-cover md:h-72 md:w-72" /></div>
          </div>
        </div>
      </section>

      <section id="topup" className="mt-20 space-y-8">
        <div className="glass p-6">
          <h2 className="mb-4 text-xl font-bold text-platinum">Langkah 1 — Verifikasi Akun Roblox</h2>
          <div className="grid gap-4 md:grid-cols-2">
            <input className="input" placeholder="Roblox Username" value={username} maxLength={20} onChange={e => { setUsername(e.target.value); resetV(); }} />
            <input className="input" placeholder="Roblox Display Name" value={displayName} maxLength={40} onChange={e => { setDisplayName(e.target.value); resetV(); }} />
          </div>
          <button className="btn mt-4" disabled={verifying || !username.trim() || !displayName.trim()} onClick={verify}>{verifying ? 'MEMERIKSA…' : 'VERIFIKASI AKUN'}</button>
          {v?.status === 'VERIFIED' && (
            <div className="mt-5 flex items-center gap-4 rounded-xl border border-emerald-400/30 bg-emerald-400/5 p-4">
              {v.avatar && <img src={v.avatar} alt="Avatar Roblox" className="h-20 w-20 rounded-xl bg-black/40" />}
              <div><span className="rounded-full bg-gradient-to-r from-silver to-emerald-400 px-3 py-1 text-xs font-bold text-ink">VERIFIED</span>
                <p className="mt-2 font-semibold">{v.displayName}</p><p className="text-sm text-silver">@{v.name}</p></div>
            </div>)}
          {v && v.status !== 'VERIFIED' && <p className="mt-4 rounded-xl border border-red-400/30 bg-red-400/10 p-3 font-bold text-red-300">{v.status === 'NOT_FOUND' ? 'NOT FOUND' : 'FAILED'} — periksa kembali username & display name.</p>}
        </div>

        <div className="glass p-6">
          <h2 className="mb-4 text-xl font-bold text-platinum">Langkah 2 — Pilih Paket Robux</h2>
          <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
            {PACKAGES.map(p => (
              <button key={p} onClick={() => { setRobux(p); setCustom(''); }} className={`relative rounded-xl border p-4 text-left transition duration-300 hover:-translate-y-1 ${robux === p && !custom ? 'border-neon bg-neon/10' : 'border-white/10 bg-white/[0.03] hover:border-electric/50'}`}>
                {POPULAR.includes(p) && <span className="absolute right-2 top-2 rounded bg-electric/20 px-2 py-0.5 text-[10px] font-bold text-electric">POPULAR</span>}
                <p className="text-2xl font-extrabold text-platinum">{p.toLocaleString('id-ID')}</p><p className="text-xs text-silver">Robux</p>
                <p className="mt-2 text-sm">{rupiah(p * PRICE_PER_ROBUX)}</p>
              </button>))}
          </div>
          <div className="mt-5">
            <label className="mb-2 block text-sm text-silver">Atau masukkan jumlah sendiri (kelipatan 50)</label>
            <input className="input" inputMode="numeric" placeholder="Contoh: 350" value={custom}
              onChange={e => { const v = e.target.value.replace(/\D/g, '').slice(0, 5); setCustom(v); const n = Number(v); setRobux(isValidRobux(n) ? n : null); }} />
            {custom && !isValidRobux(Number(custom)) && (
              <p className="mt-2 text-sm text-red-300">Harus kelipatan 50, minimal {MIN_ROBUX} dan maksimal {MAX_ROBUX.toLocaleString('id-ID')}.</p>)}
          </div>
          <p className="mt-4 text-right text-lg">Total: <b className="metal-text text-2xl">{rupiah(total)}</b></p>
        </div>

        <div className="glass p-6">
          <h2 className="mb-4 text-xl font-bold text-platinum">Langkah 3 — Pembayaran</h2>
          <select className="input" value={method} onChange={e => setMethod(e.target.value)}>
            <option value="">Pilih metode pembayaran</option>
            {Object.entries(PAYMENTS).map(([k, p]) => <option key={k} value={k}>{p.label}</option>)}
          </select>
          {pm && <div className="mt-4 rounded-xl border border-white/10 bg-black/30 p-4 text-sm">
            {pm.qris && <img src="/images/qris-zycoo-store.png" alt="QRIS ZYCOO STORE" className="mx-auto mb-3 max-h-72 rounded-lg bg-white p-2" />}
            {pm.lines.map(l => <p key={l}>{l}</p>)}</div>}
          <div className="mt-5 space-y-3">
            {TERMS.map((t, i) => (
              <label key={i} className="flex cursor-pointer gap-3 text-sm text-silver">
                <input type="checkbox" className="mt-1 accent-purple-500" checked={checks[i]} onChange={e => setChecks(c => c.map((x, j) => j === i ? e.target.checked : x))} /><span>{t}</span>
              </label>))}
          </div>
          {err && <p className="mt-4 text-sm text-red-300">{err}</p>}
          <button className="btn mt-6 w-full" disabled={!ready} onClick={pay}>{paying ? 'MEMPROSES…' : `Bayar Sekarang ${total ? '· ' + rupiah(total) : ''}`}</button>
          {!verified && <p className="mt-2 text-center text-xs text-white/40">Verifikasi akun Roblox terlebih dahulu untuk mengaktifkan pembayaran.</p>}
        </div>
      </section>
    </main>
  );
}
