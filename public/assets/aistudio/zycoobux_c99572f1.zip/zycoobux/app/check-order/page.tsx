'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
export default function CheckOrder() {
  const [id, setId] = useState(''); const [err, setErr] = useState(''); const [busy, setBusy] = useState(false);
  const router = useRouter();
  async function go(e: React.FormEvent) {
    e.preventDefault(); setErr(''); setBusy(true);
    const v = id.trim().toUpperCase();
    try {
      const r = await fetch(`/api/orders/${encodeURIComponent(v)}`);
      if (!r.ok) throw new Error((await r.json()).error || 'Tidak ditemukan');
      router.push(`/invoice/${v}`);
    } catch (e: any) { setErr(e.message); setBusy(false); }
  }
  return (
    <main className="mx-auto max-w-md px-4 pt-20">
      <form onSubmit={go} className="glass space-y-4 p-6">
        <h1 className="metal-text text-2xl font-bold">Cek Pesanan</h1>
        <input className="input uppercase" placeholder="ZYC12345678" value={id} onChange={e => setId(e.target.value)} maxLength={11} />
        {err && <p className="text-sm text-red-300">{err}</p>}
        <button className="btn w-full" disabled={busy || id.trim().length < 5}>{busy ? 'Mencari…' : 'Lacak Pesanan'}</button>
      </form>
    </main>
  );
}
