'use client';
import { useCallback, useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { rupiah } from '@/lib/config';
import type { Order } from '@/lib/supabase';
export default function Dashboard() {
  const [orders, setOrders] = useState<Order[]>([]); const [loading, setLoading] = useState(true); const [err, setErr] = useState(''); const router = useRouter();
  const load = useCallback(async () => {
    const r = await fetch('/api/admin/orders');
    if (r.status === 401) return router.push('/admin/login');
    r.ok ? setOrders(await r.json()) : setErr('Gagal memuat data'); setLoading(false);
  }, [router]);
  useEffect(() => { load(); const t = setInterval(load, 15000); return () => clearInterval(t); }, [load]);
  async function setStatus(id: string, status: string) {
    const r = await fetch(`/api/orders/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) });
    r.ok ? load() : setErr('Gagal update status');
  }
  async function logout() { await fetch('/api/admin/login', { method: 'DELETE' }); router.push('/admin/login'); }
  const done = orders.filter(o => o.status === 'COMPLETED');
  const stats = [['Total Pendapatan Sukses', rupiah(done.reduce((s, o) => s + o.price_paid, 0))], ['Antrean Pending', String(orders.filter(o => o.status === 'PENDING').length)], ['Total Pesanan Berhasil', String(done.length)]];
  return (
    <main className="mx-auto max-w-6xl px-4 pt-10">
      <div className="flex items-center justify-between"><h1 className="metal-text text-2xl font-bold">Dashboard Admin</h1><button onClick={logout} className="text-sm text-silver hover:text-white">Keluar</button></div>
      <div className="mt-6 grid gap-4 md:grid-cols-3">{stats.map(([k, v]) => <div key={k} className="glass p-5"><p className="text-xs text-silver">{k}</p><p className="mt-1 text-2xl font-extrabold text-platinum">{v}</p></div>)}</div>
      {err && <p className="mt-4 text-red-300">{err}</p>}
      <div className="glass mt-6 overflow-x-auto">
        <table className="w-full min-w-[800px] text-left text-sm">
          <thead className="text-xs uppercase text-silver"><tr>{['ID', 'Akun', 'Robux', 'Total', 'Metode', 'Status', 'Aksi'].map(h => <th key={h} className="p-3">{h}</th>)}</tr></thead>
          <tbody>
            {loading && <tr><td className="p-4 text-silver" colSpan={7}>Memuat…</td></tr>}
            {orders.map(o => (
              <tr key={o.id} className="border-t border-white/5">
                <td className="p-3 font-mono">{o.id}</td><td className="p-3">{o.roblox_display_name}<br /><span className="text-xs text-silver">@{o.roblox_username}</span></td>
                <td className="p-3">{o.robux_amount}</td><td className="p-3">{rupiah(o.price_paid)}</td><td className="p-3">{o.payment_method}</td><td className="p-3">{o.status}</td>
                <td className="space-x-2 p-3">
                  <button disabled={o.status === 'COMPLETED'} onClick={() => setStatus(o.id, 'COMPLETED')} className="rounded-lg bg-emerald-500/20 px-3 py-1 text-emerald-300 disabled:opacity-30">Selesaikan</button>
                  <button disabled={o.status === 'CANCELLED'} onClick={() => confirm('Batalkan pesanan ini?') && setStatus(o.id, 'CANCELLED')} className="rounded-lg bg-red-500/20 px-3 py-1 text-red-300 disabled:opacity-30">Batalkan</button>
                </td></tr>))}
          </tbody>
        </table>
      </div>
    </main>
  );
}
