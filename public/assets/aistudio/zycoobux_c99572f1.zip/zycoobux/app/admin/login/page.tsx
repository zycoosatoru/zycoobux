'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
export default function AdminLogin() {
  const [u, setU] = useState(''); const [p, setP] = useState(''); const [err, setErr] = useState(''); const router = useRouter();
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setErr('');
    const r = await fetch('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: u, password: p }) });
    r.ok ? router.push('/admin/dashboard') : setErr((await r.json()).error || 'Login gagal');
  }
  return (
    <main className="mx-auto max-w-sm px-4 pt-24">
      <form onSubmit={submit} className="glass space-y-4 p-6">
        <h1 className="metal-text text-2xl font-bold">Admin Login</h1>
        <input className="input" placeholder="Username" value={u} onChange={e => setU(e.target.value)} autoComplete="username" />
        <input className="input" type="password" placeholder="Password" value={p} onChange={e => setP(e.target.value)} autoComplete="current-password" />
        {err && <p className="text-sm text-red-300">{err}</p>}
        <button className="btn w-full">Masuk</button>
      </form>
    </main>
  );
}
