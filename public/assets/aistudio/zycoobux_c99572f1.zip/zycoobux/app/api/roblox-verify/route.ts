import { NextResponse } from 'next/server';
import { verifyRoblox, USERNAME_RE } from '@/lib/roblox';
export async function POST(req: Request) {
  try {
    const { username, displayName } = await req.json();
    if (typeof username !== 'string' || typeof displayName !== 'string' || !USERNAME_RE.test(username.trim()) || !displayName.trim() || displayName.length > 40)
      return NextResponse.json({ status: 'FAILED', error: 'Input tidak valid' }, { status: 400 });
    return NextResponse.json(await verifyRoblox(username.trim(), displayName));
  } catch {
    return NextResponse.json({ status: 'FAILED', error: 'Layanan Roblox tidak tersedia, coba lagi.' }, { status: 502 });
  }
}
