import { NextResponse } from 'next/server';
import { supabase } from '@/lib/supabase';
import { isAdmin } from '@/lib/auth';
import { STATUSES } from '@/lib/config';
const ID_RE = /^ZYC\d{8}$/;

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const id = params.id.toUpperCase();
  if (!ID_RE.test(id)) return NextResponse.json({ error: 'ID tidak valid' }, { status: 400 });
  const { data, error } = await supabase.from('orders').select('*').eq('id', id).maybeSingle();
  if (error) return NextResponse.json({ error: 'Server error' }, { status: 500 });
  if (!data) return NextResponse.json({ error: 'Pesanan tidak ditemukan' }, { status: 404 });
  return NextResponse.json(data);
}
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  if (!isAdmin()) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  const { status } = await req.json().catch(() => ({}));
  if (!ID_RE.test(params.id) || !(STATUSES as readonly string[]).includes(status))
    return NextResponse.json({ error: 'Input tidak valid' }, { status: 400 });
  const { error } = await supabase.from('orders').update({ status, updated_at: new Date().toISOString() }).eq('id', params.id);
  if (error) return NextResponse.json({ error: 'Server error' }, { status: 500 });
  return NextResponse.json({ ok: true });
}
