import { NextResponse } from 'next/server';
import { randomInt } from 'crypto';
import { supabase } from '@/lib/supabase';
import { verifyRoblox, USERNAME_RE } from '@/lib/roblox';
import { isValidRobux, PAYMENTS, PRICE_PER_ROBUX } from '@/lib/config';
const bad = (error: string, status = 400) => NextResponse.json({ error }, { status });

export async function POST(req: Request) {
  try {
    const b = await req.json();
    const username = String(b.username ?? '').trim(), displayName = String(b.displayName ?? '').trim();
    const robux = Number(b.robux), method = String(b.paymentMethod ?? '');
    if (!USERNAME_RE.test(username) || !displayName) return bad('Data akun tidak valid');
    if (!isValidRobux(robux)) return bad('Jumlah Robux harus kelipatan 50 (50 - 50.000)');
    if (!(method in PAYMENTS)) return bad('Metode pembayaran tidak valid');
    if (b.agreed !== true) return bad('Syarat belum disetujui');

    // Verifikasi ulang di server: status "VERIFIED" dari client tidak dipercaya.
    const v = await verifyRoblox(username, displayName);
    if (v.status !== 'VERIFIED') return bad('Akun Roblox tidak terverifikasi', 422);

    const price = robux * PRICE_PER_ROBUX; // harga SELALU dihitung server
    for (let i = 0; i < 5; i++) {
      const id = 'ZYC' + randomInt(0, 100_000_000).toString().padStart(8, '0');
      const { error } = await supabase.from('orders').insert({
        id, roblox_username: v.name, roblox_display_name: v.displayName, roblox_user_id: v.id,
        robux_amount: robux, price_paid: price, payment_method: method, status: 'PENDING',
      });
      if (!error) return NextResponse.json({ orderId: id });
      if (error.code !== '23505') throw error; // selain bentrok ID -> error
    }
    return bad('Gagal membuat pesanan, coba lagi', 500);
  } catch (e) {
    console.error('checkout', e);
    return bad('Terjadi kesalahan server', 500);
  }
}
