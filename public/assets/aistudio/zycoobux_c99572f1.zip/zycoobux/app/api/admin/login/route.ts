import { NextResponse } from 'next/server';
import { COOKIE, makeToken, safeEq } from '@/lib/auth';
export async function POST(req: Request) {
  const { username, password } = await req.json().catch(() => ({}));
  const u = process.env.ADMIN_USERNAME, p = process.env.ADMIN_PASSWORD;
  if (!u || !p || process.env.ADMIN_SESSION_SECRET?.length! < 16)
    return NextResponse.json({ error: 'Server belum dikonfigurasi' }, { status: 500 });
  const ok = safeEq(String(username ?? ''), u) && safeEq(String(password ?? ''), p);
  if (!ok) { await new Promise(r => setTimeout(r, 600)); return NextResponse.json({ error: 'Login gagal' }, { status: 401 }); }
  const res = NextResponse.json({ ok: true });
  res.cookies.set(COOKIE, makeToken(), { httpOnly: true, sameSite: 'strict', secure: process.env.NODE_ENV === 'production', path: '/', maxAge: 8 * 3600 });
  return res;
}
export async function DELETE() {
  const res = NextResponse.json({ ok: true }); res.cookies.delete(COOKIE); return res;
}
