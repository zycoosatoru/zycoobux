'use client';
import { useEffect, useState } from 'react';
import { PAYMENTS, rupiah } from '@/lib/config';
import type { Order } from '@/lib/supabase';
const COLORS: Record<string, string> = { PENDING: 'bg-amber-400/20 text-amber-300', PAID: 'bg-electric/20 text-electric', PROCESSING: 'bg-neon/20 text-neon', COMPLETED: 'bg-emerald-400/20 text-emerald-300', CANCELLED: 'bg-red-400/20 text-red-300' };
export default function Invoice({ params }: { params: { id: string } }) {
  const [o, setO] = useState<Order | null>(null); const [err, setErr] = useState('');
  useEffect(() => {
    fetch(`/api/orders/${params.id}`).then(async r => { const d = await r.json(); r.ok ? setO(d) : setErr(d.error || 'Error'); }).catch(() => setErr('Gagal memuat'));
  }, [params.id]);
  if (err) return <main className="px-4 pt-24 text-center text-red-300">{err}</main>;
  if (!o) return <main className="px-4 pt-24 text-center text-silver">Memuat invoice…</main>;
  const pm = PAYMENTS[o.payment_method];
  const row = (k: string, v: string) => <div className="flex justify-between gap-4 border-b border-white/5 py-2 text-sm"><span className="text-silver">{k}</span><span className="text-right font-medium">{v}</span></div>;
  return (
    <main className="mx-auto max-w-xl px-4 pt-12">
      <div className="glass p-6">
        <div className="flex items-start justify-between">
          <div><p className="metal-text text-xl font-extrabold tracking-widest">ZYCOOBUX</p><p className="text-xs text-silver">Invoice Digital</p></div>
          <span className={`rounded-full px-3 py-1 text-xs font-bold ${COLORS[o.status]}`}>{o.status}</span>
        </div>
        <div className="mt-6">
          {row('ID Pesanan', o.id)}{row('Tanggal', new Date(o.created_at).toLocaleString('id-ID'))}
          {row('Username Roblox', '@' + o.roblox_username)}{row('Display Name', o.roblox_display_name)}
          {row('Jumlah Robux', o.robux_amount.toLocaleString('id-ID'))}{row('Metode', pm?.label ?? o.payment_method)}
          <div className="flex justify-between pt-4 text-lg"><span>Total Tagihan</span><b className="metal-text text-2xl">{rupiah(o.price_paid)}</b></div>
        </div>
        {pm && <div className="mt-6 rounded-xl border border-white/10 bg-black/30 p-4 text-sm">
          <p className="mb-2 font-semibold text-platinum">Instruksi Pembayaran</p>
          {pm.qris && <img src="/images/qris-zycoo-store.png" alt="QRIS" className="mx-auto mb-3 max-h-72 rounded-lg bg-white p-2" />}
          {pm.lines.map(l => <p key={l}>{l}</p>)}
          <p className="mt-3 text-xs text-white/50">Transfer sesuai nominal tepat, lalu kirim bukti pembayaran + ID pesanan ke CS WhatsApp.</p>
        </div>}
      </div>
    </main>
  );
}
