import './globals.css';
import type { Metadata } from 'next';
import Navbar from '@/components/Navbar';
import Footer from '@/components/Footer';
import WhatsAppWidget from '@/components/WhatsAppWidget';
export const metadata: Metadata = { title: 'ZYCOOBUX — Premium Robux Store', description: 'Premium Robux Store. Beyond Ordinary.' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="id"><body className="min-h-screen antialiased"><Navbar />{children}<Footer /><WhatsAppWidget /></body></html>);
}
