import Link from 'next/link';
export default function Navbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-ink/70 backdrop-blur-xl">
      <nav className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link href="/" className="flex items-center gap-3">
          <img src="/images/logo-zycoo.png" alt="ZYCOOBUX" className="h-9 w-9 rounded-lg border border-silver/50 object-cover" />
          <span className="metal-text text-lg font-extrabold tracking-widest">ZYCOOBUX</span>
        </Link>
        <div className="flex items-center gap-5 text-sm text-silver">
          <Link href="/" className="transition hover:text-white">Home</Link>
          <Link href="/#topup" className="transition hover:text-white">Top Up</Link>
          <Link href="/check-order" className="transition hover:text-white">Cek Pesanan</Link>
          <Link href="/admin/login" title="Admin Area" aria-label="Admin Area" className="text-[10px] text-white/15 transition hover:text-white/60">●</Link>
        </div>
      </nav>
    </header>
  );
}
