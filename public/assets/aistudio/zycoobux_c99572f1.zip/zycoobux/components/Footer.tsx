import Link from 'next/link';
export default function Footer() {
  return (
    <footer className="mt-24 border-t border-white/10 px-4 py-10 text-sm text-silver">
      <div className="mx-auto grid max-w-6xl gap-8 md:grid-cols-3">
        <div><p className="metal-text text-xl font-extrabold tracking-widest">ZYCOOBUX</p><p className="mt-2">Premium Robux Store. Beyond Ordinary.</p></div>
        <div className="space-y-1"><p className="font-semibold text-platinum">Bantuan</p>
          <Link className="block hover:text-white" href="/check-order">Cek Pesanan</Link>
          <Link className="block hover:text-white" href="/#topup">Cara Top Up</Link>
          <a className="block hover:text-white" href="https://wa.me/6281288872390" target="_blank" rel="noopener noreferrer">Hubungi CS</a></div>
        <div className="space-y-1"><p className="font-semibold text-platinum">Kontak & Komunitas</p><p>WhatsApp: 0812-8887-2390</p>
          <a className="block hover:text-white" href="https://whatsapp.com/channel/0029VbEy14z0AgWBwk9sdm03" target="_blank" rel="noopener noreferrer">Saluran WhatsApp</a>
          <a className="block hover:text-white" href="https://whatsapp.com/channel/0029VbEy14z0AgWBwk9sdm03/135" target="_blank" rel="noopener noreferrer">Grup WhatsApp</a></div>
      </div>
      <p className="mx-auto mt-8 max-w-6xl border-t border-white/10 pt-6 text-xs text-white/50">
        ZYCOOBUX adalah toko independen dan tidak berafiliasi, disponsori, atau didukung oleh Roblox Corporation. Roblox dan merek dagangnya merupakan milik pemiliknya masing-masing.
      </p>
    </footer>
  );
}
