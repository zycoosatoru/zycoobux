import { WA_NUMBER } from '@/lib/config';
export default function WhatsAppWidget() {
  const msg = encodeURIComponent('Halo ZYCOOBUX CS 👋, saya ingin bertanya tentang top up Robux.');
  return (
    <a href={`https://wa.me/${WA_NUMBER}?text=${msg}`} target="_blank" rel="noopener noreferrer" aria-label="Chat WhatsApp CS"
      className="fixed bottom-5 right-5 z-50 flex items-center gap-2 rounded-full border border-white/15 bg-emerald-600/90 px-5 py-3 text-sm font-semibold text-white shadow-lg backdrop-blur transition hover:-translate-y-1 hover:bg-emerald-500">
      <span>💬</span><span className="hidden sm:inline">Chat CS</span>
    </a>
  );
}
