import { createHmac, createHash, timingSafeEqual } from 'crypto';
import { cookies } from 'next/headers';
export const COOKIE = 'zy_admin';
const secret = () => process.env.ADMIN_SESSION_SECRET || '';
const sign = (p: string) => createHmac('sha256', secret()).update(p).digest('hex');
const h = (s: string) => createHash('sha256').update(s).digest();
export const safeEq = (a: string, b: string) => timingSafeEqual(h(a), h(b));
export function makeToken() { const exp = String(Date.now() + 8 * 3600_000); return `${exp}.${sign(exp)}`; }
export function isAdmin(): boolean {
  if (secret().length < 16) return false;
  const t = cookies().get(COOKIE)?.value; if (!t) return false;
  const [exp, sig] = t.split('.'); if (!exp || !sig) return false;
  return safeEq(sig, sign(exp)) && Number(exp) > Date.now();
}
