export const PRICE_PER_ROBUX = 165;
export const PACKAGES = [50, 100, 250, 500, 1000, 2000, 3000, 5000];
export const MIN_ROBUX = 50;
export const STEP_ROBUX = 50;
export const MAX_ROBUX = 50000;
export const isValidRobux = (n: number) =>
  Number.isInteger(n) && n >= MIN_ROBUX && n <= MAX_ROBUX && n % STEP_ROBUX === 0;
export const POPULAR = [250, 1000];
export const STATUSES = ['PENDING', 'PAID', 'PROCESSING', 'COMPLETED', 'CANCELLED'] as const;
export const WA_NUMBER = '6281288872390';
export const rupiah = (n: number) => 'Rp ' + n.toLocaleString('id-ID');

export type Payment = { label: string; qris?: boolean; lines: string[] };
export const PAYMENTS: Record<string, Payment> = {
  QRIS: { label: 'QRIS', qris: true, lines: ['Merchant: zycoo store', 'NMID: ID1026511358586'] },
  DANA: { label: 'DANA', lines: ['Nomor: 081288872390', 'a.n. romlah'] },
  GOPAY: { label: 'GoPay', lines: ['Nomor: 081288872390', 'a.n. Muhammad Azky Alfarizi'] },
  SHOPEEPAY: { label: 'ShopeePay', lines: ['Nomor: 081288872390', 'a.n. Muhammad Azky Alfarizi'] },
  SEABANK: { label: 'SeaBank', lines: ['Rekening SeaBank: 901621421075', 'a.n. Muhammad Azky Alfarizi'] },
};
export const TERMS = [
  'Akun Roblox saya sudah terverifikasi usia 18+.',
  'Limit akun Roblox saya sudah dicek.',
];
