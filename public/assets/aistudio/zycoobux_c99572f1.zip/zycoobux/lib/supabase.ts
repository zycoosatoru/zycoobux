import { createClient } from '@supabase/supabase-js';
// Server-only. Jangan pernah import file ini dari komponen client.
export const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY!,
  { auth: { persistSession: false } }
);
export type Order = {
  id: string; roblox_username: string; roblox_display_name: string; roblox_user_id: string;
  robux_amount: number; price_paid: number; payment_method: string; status: string;
  created_at: string; updated_at: string;
};
