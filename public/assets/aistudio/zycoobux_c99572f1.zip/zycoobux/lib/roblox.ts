export type Verify =
  | { status: 'VERIFIED'; id: string; name: string; displayName: string; avatar: string | null }
  | { status: 'FAILED' | 'NOT_FOUND' };
export const USERNAME_RE = /^[A-Za-z0-9_]{3,20}$/;

export async function verifyRoblox(username: string, displayName: string): Promise<Verify> {
  const r = await fetch('https://users.roblox.com/v1/usernames/users', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ usernames: [username], excludeBannedUsers: true }), cache: 'no-store',
  });
  if (!r.ok) throw new Error('ROBLOX_UPSTREAM');
  const u = (await r.json()).data?.[0];
  if (!u) return { status: 'NOT_FOUND' };
  if (String(u.displayName).toLowerCase() !== displayName.trim().toLowerCase()) return { status: 'FAILED' };
  let avatar: string | null = null;
  try {
    const a = await fetch(`https://thumbnails.roblox.com/v1/users/avatar?userIds=${u.id}&size=150x150&format=Png`, { cache: 'no-store' });
    if (a.ok) avatar = (await a.json()).data?.[0]?.imageUrl ?? null;
  } catch {}
  return { status: 'VERIFIED', id: String(u.id), name: u.name, displayName: u.displayName, avatar };
}
