# ZYCOOBUX
1. `npm install`
2. Jalankan `supabase.sql` di Supabase SQL Editor.
3. `cp .env.example .env.local` lalu isi nilainya (ganti password admin & secret!).
4. Taruh `logo-zycoo.png` dan `qris-zycoo-store.png` di `public/images/`.
5. `npm run dev`
