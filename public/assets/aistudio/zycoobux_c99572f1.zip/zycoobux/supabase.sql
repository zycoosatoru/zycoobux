create table if not exists public.orders (
  id varchar primary key,
  roblox_username varchar not null,
  roblox_display_name varchar not null,
  roblox_user_id varchar not null,
  robux_amount int not null check (robux_amount > 0),
  price_paid int not null check (price_paid > 0),
  payment_method varchar not null,
  status varchar not null default 'PENDING'
    check (status in ('PENDING','PAID','PROCESSING','COMPLETED','CANCELLED')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists orders_created_idx on public.orders (created_at desc);
-- RLS aktif tanpa policy: hanya service role (server) yang bisa akses.
alter table public.orders enable row level security;
